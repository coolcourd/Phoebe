# Where to get help

If you think you've found a bug in The Cayman Blog Theme, please [check the existing issues](https://github.com/lorepirri/cayman-blog/issues), and if no one has reported the problem, [open a new issue](https://github.com/lorepirri/cayman-blog/issues/new).
